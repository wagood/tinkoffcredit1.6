# tinkoffcredit1.6
Module for Prestashop 1.6 that allow Tinkoff Credit button and payment

Модуль для Prestashop 1.6 который выводит кнопку и метод оплаты для работы с Tinkoff Credit / Купить в кредит
